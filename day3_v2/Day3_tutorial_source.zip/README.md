# Day 3 tutorial: fungal traits, PCA and similarity

A two-hour practical for ecology-background bachelor students, including a five-minute break and five-minute troubleshooting buffer. The lesson starts directly with an example workflow using extension, melanisation, cellobiohydrolase activity, spore abundance and hyphal diameter. Step 3 includes the resulting score plot inside its Check; Step 4 adds the five trait arrows and supplies an interpretation of the variance, axis contrasts and trait associations, without a separate interpretation task. Students then repeat the flow with five other chosen traits.

The route removes the refresher, question-and-route section, invented demonstration and extra discussion/extension exercises, uses one clustering cut (k=3), and replaces separate reports with brief script comments. The complete plotting and saving commands are supplied in the starter script to keep the work within 120 minutes. See `Instructor_notes.md` for the schedule.

## Open or publish

Open `dist/index.html` to read the finished tutorial locally. No R server is needed; students execute R in RStudio. Browser checklists are local and no student answers are collected. The revised checklist uses a new storage key so previous completion ticks do not mark the new tasks complete.

Upload the **entire `day3_v2` folder** into the GitHub Pages publishing root beside the other tutorial folders. Alternatively, unzip `Day3_GitHub_ready.zip` and upload its `day3_v2` folder. Keep `index.html` and every adjacent download together. Extract publication ZIPs before uploading.

Expected URL after GitHub publishes the uploaded folder:

https://mohanb96.github.io/Ecological-data-analysis-with-R/day3_v2/

Course homepage link:

```markdown
[Day 3: Fungal traits, PCA and similarity](https://mohanb96.github.io/Ecological-data-analysis-with-R/day3_v2/)
```

## Student files and outputs

`Day3_student_files.zip` contains the RStudio project, starter script, curated real data, full real dataset and expanded trait dictionary. Extract all files into one folder and open `ABV_Day3.Rproj`. Only `ggplot2` is needed beyond base R for the required workflow; arrow drawing uses the bundled `grid` package. The complete core reference script is a separate download.

Students first complete the guided script, including Step 7 saving, then copy it into a second script for Step 6. They replace the import, output folder and five trait names, and repeat inspection, missing-value handling, scaling, PCA, arrows, interpretation, clustering and saving. The eight documented independent choices are `density`, `water_cont`, `hydrop`, `C_cont`, `enz_leu`, `enz_pho`, `spore_shape` and `spore_size`. Students choose five with no overlap with the guided set.

The two scripts save to `outputs/guided` and `outputs/your_five_traits`, respectively. Each automatically saves selected trait names, PCA scores with species labels and all five PCs, PC1/PC2 loadings, explained variance, cluster profiles, retained/excluded records, a PCA with arrows and a dendrogram. Students add short comments at the supplied NOTE lines. Step 6 requires one sentence justifying selection and three brief notes; no separate report is required.

## Edit and rebuild

Edit `D3_traits_v2.Rmd` and the files in `assets/`. Run `source("build.R")` from this directory, or `Rscript --vanilla build.R`. Rendering requires `rmarkdown`, `knitr`, `ggplot2` and Pandoc (included with RStudio). The script creates self-contained HTML, the generated reference script, downloads, source ZIP, publication folder and GitHub ZIP. It executes examples in a temporary directory to keep analysis exports out of the source folder.

`Day3_complete.R` and the ready-to-run `Day3_starter.R` are generated from the required executable chunks. The starter adds section headings and interpretation prompts; it contains all analysis, plotting and saving commands. Edit the `.Rmd` and the section prompts in `build.R` rather than editing the generated scripts. Reference-only plots and the independent trait-selection/checking templates are excluded. Students choose and interpret their own five traits in Step 6.

## Data provenance and curation

`Fungal_traits_full.csv` is an unchanged copy of `Day_3/Fungal_traits.csv`, supplied by Mohan Bi. `Fungal_traits_day3.csv` retains all 31 original rows and nine named columns: four metadata columns and five analysis traits. CSV text values are preserved without imputation, transformations or row removal. Extension, melanisation, cellobiohydrolase activity and spore abundance have missing data in DF25, DISC and M; hyphal diameter is complete. The guided analysis excludes those three rows and retains 28 isolate records.

The independent pool is numeric and nonconstant. Five-trait selections including `density` retain 28 isolates; selections excluding it retain 31. Students must recalculate exclusions for their chosen traits. A comparison that changes both traits and retained IDs cannot attribute all differences solely to trait choice.

The original CSV does not record raw units or the full preprocessing history. Values are therefore labelled as supplied course scales; negative processed extension/spore values are explicitly explained. Consult original study methods before further transformations or biological interpretations requiring raw magnitudes. Research context: Camenzind et al. (2024), https://doi.org/10.1038/s41467-024-47705-7. This exercise is a teaching subset, not a reproduction of the paper's full analysis.

## Reference values

For the guided five traits, standardised PCA retains 28 isolates. Variance explained: PC1 44.821566%, PC2 20.760029%, together 65.581595%. PC3–PC5 contain the remaining 34.418405%. With the reference signs, PC1 loadings are extension +0.5054, melanin -0.4869, enz_cel -0.4720, spore_abund +0.5028 and hyphal_diam +0.1785. Hyphal diameter dominates PC2 with a loading of -0.8920. Axis signs may reverse together without changing relationships.

The required PCA overlay uses PC1/PC2 loadings multiplied by the same display factor, 2.5. It preserves isolate scores and equal axis units. Arrow lengths are not ecological importance, point-to-tip distances are not trait measurements, and loading-arrow angles are not exact correlations. Check projected trait predictions against recorded values.

Complete-linkage clustering of Euclidean distances from all five scaled traits gives three clusters of 5, 18 and 5 isolates under reference numbering. Numeric labels are arbitrary; compare IDs and memberships. There is no single reference result for Step 6 because students choose their own five traits.
