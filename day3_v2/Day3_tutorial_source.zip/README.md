# Day 3 tutorial: fungal traits, PCA and similarity

A three-hour practical for ecology-background bachelor students. It preserves the progression from exploration and scaling to PCA and hierarchical clustering. Six whole-class R questions start the lesson, with a classroom presentation mode. A short invented example introduces similarity; the main practical uses four traits from the supplied real fungal dataset.

## Open or publish

Open `dist/index.html` to read the finished tutorial locally. No R server is needed for the website; students execute R in RStudio. Browser checklists are local and no student answers are collected.

Upload the **entire `day3_v2` folder** into the GitHub Pages publishing root beside `day1_v2` and `day2_v2`. Alternatively, unzip `Day3_GitHub_ready.zip` and upload its `day3_v2` folder. Keep `index.html` and every adjacent download together. A ZIP uploaded without extraction will not become the tutorial page.

Expected URL after GitHub publishes the uploaded folder:

https://mohanb96.github.io/Ecological-data-analysis-with-R/day3_v2/

Add this link to the course homepage README:

```markdown
[Day 3: Fungal traits, PCA and similarity](https://mohanb96.github.io/Ecological-data-analysis-with-R/day3_v2/)
```

## Student files

`Day3_student_files.zip` contains the RStudio project, starter script, two clearly distinguished datasets, and the trait dictionary. Extract all files into one folder and open `ABV_Day3.Rproj`. Only `ggplot2` is needed beyond base R for the required workflow. The complete reference script and original full dataset are separate downloads.

## Edit and rebuild

Edit `D3_traits_v2.Rmd` and the files in `assets/`. Run `source("build.R")` from this directory, or `Rscript --vanilla build.R`. Rendering requires R packages `rmarkdown`, `knitr`, and `ggplot2`, plus Pandoc (included with RStudio). The script creates a self-contained HTML page, the generated reference script, downloads, source ZIP, publication folder and GitHub ZIP. It executes examples in a temporary directory to avoid scattering analysis exports into the source folder.

`Day3_complete.R` is generated from required executable chunks. The refresher, invented-data demonstration, answer-only plotting code, transfer exercise solution, and optional extension are excluded. The complete script supplies cluster profiles; the student's main interpretive task still requires their own words.

## Data provenance and curation

`Fungal_traits_full.csv` is an unchanged copy of `Day_3/Fungal_traits.csv`, supplied by Mohan Bi. `Fungal_traits_day3.csv` retains all 31 original rows and eight named columns: four identifiers/metadata columns and four analysis traits. CSV text values are preserved without imputation, transformations or row removal. Three rows have missing selected traits; the analysis transparently excludes those rows, retaining 28 isolates. These are isolate-level records, not 28 replicate observations of one species or treatment.

The original CSV does not record raw units or the full preprocessing history. The tutorial therefore labels its values as supplied course scales, explicitly explains negative processed extension/spore values, and avoids raw-unit effect claims. Consult original study methods before further transformations or biological interpretations requiring raw magnitudes. Research context: Camenzind et al. (2024), https://doi.org/10.1038/s41467-024-47705-7. The four-trait exercise is a teaching subset, not a reproduction of the paper's full analysis.

`Fungal_traits_demo.csv` is a deliberately constructed ten-isolate teaching example, not empirical data. It uses invented scales and is never combined with the real data.

## Reference values

For the four selected traits, standardised PCA retains 28 isolates. Variance explained: PC1 55.022%, PC2 19.056%, together 74.078%. Under the reference sign convention, PC1 weights extension and spore abundance positively, melanisation and cellobiohydrolase activity negatively. Axis signs may reverse across implementations without changing the pattern. Complete-linkage clustering of Euclidean distances from all four scaled traits produces three clusters with sizes 5, 17 and 6 under the reference numbering. IDs, membership and trait profiles are more meaningful checks than numeric cluster labels.
