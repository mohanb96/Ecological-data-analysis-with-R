# Instructor notes: Day 3 (two hours)

## Instructor timing: 100-minute core within two hours

| Part | Minutes |
|:---|---:|
| Inspect five traits and missing values | 10 |
| Standardise | 5 |
| PCA and explained variation | 15 |
| Add five trait arrows | 10 |
| Break | 5 |
| Clustering: one cut at k = 3 | 10 |
| Repeat the flow with five other traits | 30 |
| Save, rerun and finish short notes | 10 |
| Troubleshooting buffer | 5 |
| **Core total** | **100** |

Allow up to 20 additional minutes for setup or slower students, keeping the practical within 120 minutes. Start directly at Step 1; the student page no longer includes the refresher or question-and-route section. The chapters are numbered consecutively from 1; Help and downloads is Chapter 8. Use the supplied ready-to-run starter script. Students run named sections and add short comments; they do not copy or write plotting/export code. The ten minutes for saving cover both scripts: students save the guided outputs before copying the script for Step 6, then finish both rerun checks at the end.

## Reduced workload

The refresher and question-and-route section have been removed completely. The invented demonstration, distribution/unit-change/loading-bar exercises, extra isolate comparison, drought-tolerance discussion, k=2 versus k=3 comparison, coloured cluster map, common-isolate extension, separate reports and four exit questions have been removed. Do not reintroduce these as required classroom tasks.

Step 3 includes the resulting PCA score plot inside its Check. Step 4 keeps the loading explanation, five arrows, resulting plot and supplied PCA interpretation; it has no isolate-comparison task, answer or interpretation prompt in the starter. The independent analysis still repeats the flow with five other traits and uses three short notes: sample size and PC1-PC2 percentage; a two-isolate comparison supported by two arrows and values; one difference or limitation. Selection needs one sentence of justification.

## Data and reference checks

The teaching file has 31 rows and 9 columns. The five traits are extension, melanin, enz_cel, spore_abund and hyphal_diam. DF25, DISC and M lack the first four traits; hyphal diameter is complete. The guided matrix retains 28 isolates. Each row is an isolate record, not a replicated species mean.

Values use supplied course scales; raw units and full preprocessing are not documented. Negative extension/spore values are not negative physical growth/counts. Do not add raw units or log-transform these processed values without original metadata.

Guided PCA: PC1 44.821566%, PC2 20.760029%, together 65.581595%. PC1 loadings (reference sign): extension +0.5054, melanin -0.4869, enz_cel -0.4720, spore_abund +0.5028, hyphal_diam +0.1785. Hyphal diameter dominates PC2 (-0.8920), with spore abundance loading in the opposite direction (+0.3578). Reflecting scores and corresponding arrows together preserves the relationships.

All five loading arrows are multiplied by 2.5 for display on equal-unit score axes. Read positions along arrow directions and check original values; 34.4% of variation is omitted. Point-to-tip distances are not measurements, arrow lengths are not ecological importance, and arrow angles are not exact correlations.

A (Pyrenochaetopsis_leptospora) versus DF56 (Mucor_fragilis): extension -0.862 versus 2.373 and spore abundance -1.639 versus 1.143. These support an isolate-level trait contrast, not species-wide adaptation or field performance.

Clustering uses Euclidean distance from all five scaled traits, complete linkage and one k=3 cut. Reference groups:

- A, C21, C29, DF35, DF36 (5).
- C11, C23, C31, C33, C34, C40, C41, DF04, DF09, DF16, DF17, DF19, DF24, DF32, DF37, DF42, DF58, J (18).
- C13, C28, C35, DF10, DF56 (5).

Numeric labels are arbitrary; a three-cluster cut does not establish three natural fungal strategies. Mean scaled profiles are supplied as descriptive output, with no additional group-description assignment.

## Independent task and formative check

Students choose five from density, water_cont, hydrop, C_cont, enz_leu, enz_pho, spore_shape and spore_size, with no overlap with the guided set. The full data and dictionary are in the student ZIP. They copy their working script, replace the import, output_dir and trait_names, and rerun inspection, complete-case selection, scaling, PCA, arrows, interpretation, clustering and saving.

Selections including density retain 28 isolates; other choices retain 31. There is no single expected independent PCA or grouping. A change in retained IDs means sample composition as well as trait choice may affect comparisons.

Check two runnable scripts, separate outputs/guided and outputs/your_five_traits folders, five arrows in each PCA, selected names and retained/excluded IDs, correct explained percentages, a two-trait position interpretation in the independent analysis, and the three brief independent notes. All export commands are supplied. No separate report is required.

The supplied interpretation reports the 28 isolates and 65.6% displayed variance, the PC1 contrast between melanisation/enzyme activity and extension/spores, and the dominant hyphal-diameter direction on PC2. Vector orientations suggest the two positive trait associations; the text keeps the two-dimensional projection limitation explicit. No additional interpretation assignment is introduced.
