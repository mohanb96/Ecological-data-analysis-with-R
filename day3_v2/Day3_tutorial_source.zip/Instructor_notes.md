# Instructor notes: Day 3

## Learning focus

Students should connect a PCA position to measured traits, state what fraction of selected-trait variation is displayed, and explain why a dendrogram cut does not establish natural ecological groups. PCA is the core; clustering is a guided extension. Avoid teaching eigenvector derivations, package-specific plotting alternatives, automatic normality testing, or optimisation of cluster number in the required work.

## Timing (180 minutes)

- R refresher: 15
- Ecological question and invented example: 15
- Inspect real data, dictionary and missing values: 25
- Scaling: 20
- PCA map: 20
- Interpret axes and compare isolates: 25
- Break: 10
- Clustering: 20
- Independent cluster description: 10
- Save, rerun and communicate: 20

Use the six-question classroom mode at the start. Have students think and discuss before revealing each answer. The demonstration is instructor-led: students do not need to type vectors or complete a second analysis. All code in optional sections is additional to the three-hour required route.

## Data and interpretation checks

The teaching CSV contains 31 rows and 8 columns. The analysis matrix has 4 numeric traits. DF25, DISC and M are excluded because selected traits are missing, leaving 28 isolates. Explain that complete-case exclusion is a practical teaching choice and may change representativeness. Do not imply that missingness is random.

Original course values for extension and spore abundance are processed, including negatives. Do not attach raw mm/day or spore-count units to these values, back-transform them without original metadata, or apply log transforms simply because of the biological variable name. The trait dictionary and website are deliberately explicit about this limitation. The invented dataset has different, illustrative scales and is never pooled with the real dataset.

PCA references: PC1 55.022%, PC2 19.056%, together 74.078%. PC1 loadings (reference sign): extension +0.504, melanin -0.486, enz_cel -0.483, spore_abund +0.526. PC2 is chiefly an opposite-sign contrast between melanin (-0.703) and enz_cel (+0.711). A reflected axis with corresponding reflected scores/loadings is equally correct.

Isolate A versus DF56: extension -0.862 versus 2.373; melanin 0.449 versus 0.210; enz_cel 2.312 versus 0.963; spore_abund -1.639 versus 1.143. The four-trait map supports a descriptive contrast. It does not establish causal trade-offs, adaptation or field performance. Do not require students to use named strategy categories.

Clustering: Euclidean distances from all four scaled traits, `hclust(..., method = "complete")`, followed by exploratory cuts at k=2 and k=3. The k=3 reference groups are:

- A, C21, C29, DF35, DF36 (5): greater melanisation, lower extension and spore index.
- C11, C13, C23, C28, C33, C34, C35, C40, C41, DF09, DF10, DF16, DF19, DF32, DF37, DF42, DF56 (17): lower mean enzyme activity, higher mean extension/spore index than the other groups; substantial within-group variation remains.
- C31, DF04, DF17, DF24, DF58, J (6): greater mean cellobiohydrolase activity.

The 11-member first group at k=2 splits into the 5- and 6-member groups at k=3. Numeric group labels are arbitrary. A matching coloured PCA plot is a projection of memberships computed from the full four-trait matrix, not independent confirmation of three biological groups.

## Suggested marking (formative)

Accept any interpretation supported by the selected data. Look for: correct observation unit and sample count; reason for scaling; correct variance percentage; at least two traits supporting an isolate/cluster description; one limitation (trait selection, missing isolates, projection, small culture-based sample, lack of field validation); reproducible script and labelled outputs. Give more credit to sound interpretation than copying an expected strategy label.
