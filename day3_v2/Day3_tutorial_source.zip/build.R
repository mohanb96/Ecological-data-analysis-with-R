# Run source("build.R") from this folder in RStudio, or Rscript --vanilla build.R.
args <- commandArgs(trailingOnly = TRUE)
project_dir <- if (length(args)) normalizePath(args[1]) else getwd()
setwd(project_dir)
if (!rmarkdown::pandoc_available()) {
  bundled <- "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/tools/aarch64"
  if (file.exists(file.path(bundled, "pandoc"))) Sys.setenv(RSTUDIO_PANDOC = bundled)
}
dir.create("dist", showWarnings = FALSE)
knitr::purl("D3_traits_v2.Rmd", output = "Day3_complete.R", documentation = 0,
            quiet = TRUE)
starter_path <- tempfile("day3-starter-", fileext = ".R")
knitr::purl("D3_traits_v2.Rmd", output = starter_path, documentation = 1,
            quiet = TRUE)
starter_lines <- readLines(starter_path, encoding = "UTF-8")
unlink(starter_path)
section_notes <- list(
  "import-real" = "# 1. An example workflow with 5 fungi traits ----",
  "missing-traits" = paste("# 1. Check missing values ----",
                           "# NOTE: record the retained sample size and excluded IDs.", sep = "\n"),
  "scale-real" = paste("# 2. Standardise ----",
                       "# NOTE: explain in one line why we standardise.", sep = "\n"),
  "run-pca" = paste("# 3. PCA ----",
                    "# NOTE: record the percentage shown by PC1 and PC2 together.", sep = "\n"),
  "pca-scores" = "# 3. Isolate scores ----",
  "pca-plot" = "# 3. Draw the score map ----",
  "pca-loadings" = "# 4. Trait loadings ----",
  "pca-trait-arrows" = "# 4. Add five trait arrows ----",
  "cluster-tree" = "# 5. One exploratory cut at k = 3 ----",
  "cluster-profiles" = "# 5. Descriptive mean scaled traits ----",
  "save-results" = "# 7. Save outputs (also run before copying this script for Step 6) ----"
)
for (chunk_name in names(section_notes)) {
  index <- which(startsWith(starter_lines, paste0("## ----", chunk_name, "----")) |
                   startsWith(starter_lines, paste0("## ----", chunk_name, ",")))
  stopifnot(length(index) == 1)
  starter_lines[index] <- section_notes[[chunk_name]]
}
writeLines(c(
  "# Day 3: two-hour fungal traits practical",
  "# Extract the student ZIP and open ABV_Day3.Rproj.",
  "# Save as Day3_yourname.R. Run the supplied sections in order.",
  "# Add brief interpretation comments at NOTE lines; no separate report is needed.",
  "",
  starter_lines,
  "",
  "# 6. Repeat with five OTHER traits ----",
  "# After saving the guided outputs, save a copy as Day3_yourname_other_traits.R.",
  "# In the copy, change the import to Fungal_traits_full.csv, output_dir to",
  "# file.path(\"outputs\", \"your_five_traits\"), and trait_names to five other names.",
  "# Use the Step 6 selection checks and choose from the documented trait pool.",
  "# Explain your selection in one sentence, then rerun the same flow.",
  "# Add three brief notes: sample size and PC1-PC2 percent; two-isolate comparison",
  "# using two arrows and recorded values; one difference or limitation.",
  "# Recalculate exclusions and variance rather than copying guided results.",
  "# Restart R and rerun each saved script to finish."
), "Day3_starter.R", useBytes = TRUE)
qa_dir <- tempfile("day3-render-")
dir.create(qa_dir)
file.copy(c("Fungal_traits_day3.csv", "Fungal_traits_full.csv",
            "Day3_trait_dictionary.csv"), qa_dir)
rmarkdown::render("D3_traits_v2.Rmd", output_file = "index.html",
                  output_dir = "dist", knit_root_dir = qa_dir,
                  envir = new.env(parent = globalenv()), quiet = TRUE,
                  encoding = "UTF-8")
downloads <- c("Fungal_traits_day3.csv", "Fungal_traits_full.csv", "Day3_trait_dictionary.csv",
               "Day3_starter.R", "Day3_complete.R", "D3_traits_v2.Rmd")
file.copy(downloads, "dist", overwrite = TRUE)
student_files <- c("ABV_Day3.Rproj", "Day3_starter.R", "Fungal_traits_day3.csv",
                    "Fungal_traits_full.csv",
                    "Day3_trait_dictionary.csv")
student_zip <- file.path(project_dir, "dist", "Day3_student_files.zip")
if (file.exists(student_zip)) unlink(student_zip)
utils::zip(student_zip, files = student_files, flags = "-q")
source_files <- c(student_files, "D3_traits_v2.Rmd",
                   "Day3_complete.R", "build.R", "README.md", "Instructor_notes.md",
                   "assets/tutorial.css", "assets/navigation.html", "assets/interaction.html")
source_zip <- file.path(project_dir, "dist", "Day3_tutorial_source.zip")
if (file.exists(source_zip)) unlink(source_zip)
utils::zip(source_zip, files = source_files, flags = "-q")
unlink(qa_dir, recursive = TRUE)
dir.create("day3_v2", showWarnings = FALSE)
unlink(file.path(c("dist", "day3_v2"), "Fungal_traits_demo.csv"))
file.copy(list.files("dist", full.names = TRUE), "day3_v2", overwrite = TRUE)
github_zip <- file.path(project_dir, "Day3_GitHub_ready.zip")
if (file.exists(github_zip)) unlink(github_zip)
utils::zip(github_zip, files = list.files("day3_v2", recursive = TRUE,
                                         full.names = TRUE), flags = "-q")
cat("Built dist/index.html, downloads, day3_v2/ and Day3_GitHub_ready.zip.\n")
