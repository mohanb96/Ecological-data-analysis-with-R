# Day 2 tutorial

The lesson begins with a 15-minute whole-class refresher of six Day 1 R concepts. The instructor can reveal answers individually or use classroom view to present one question at a time. The main practical continues the control–drought WSA analysis with a mean difference, Welch confidence interval, p-value, interpretation, and an independent soil-pH task. Bootstrapping is optional; loop and function writing are not required.

## Files for students

The website serves `Day2_student_files.zip`, containing only the RStudio project, original dataset, and starter script. Students extract it and open `ABV_Day2.Rproj`. The web page provides the instructions; R commands run in RStudio. An optional reference script and bootstrap demonstration are separate downloads.

## Edit and rebuild

Edit `D2_test_v2.Rmd` for the lesson and `assets/` for layout and interactions. From this directory, run `source("build.R")` in RStudio or `Rscript --vanilla build.R` in a terminal. R packages required for rendering are `rmarkdown`, `knitr`, and `ggplot2`, with Pandoc available (RStudio includes it).

The complete core script is generated from the executable lesson chunks. Refresher questions, optional diagnostic templates, the pH answer, and optional bootstrap code are excluded from that core script. Rendering itself executes both the core workflow and reference demonstrations against a temporary copy of the data. The original CSV remains unchanged.

## Publish to the existing GitHub Pages course

Unzip `Day2_GitHub_ready.zip`. Upload the entire extracted `day2_v2` folder into the repository's existing publishing root, alongside `day1_v2`. Keep every file inside that folder, including `index.html` and the downloadable data/ZIP/R files.

With the current repository name, the expected URL after publication is:

https://mohanb96.github.io/Ecological-data-analysis-with-R/day2_v2/

Add this to the course homepage's README:

```markdown
[Day 2: Effect sizes, uncertainty and hypothesis tests](https://mohanb96.github.io/Ecological-data-analysis-with-R/day2_v2/)
```

The page is static and self-contained apart from its adjacent student downloads. It needs no server running R and no online accounts. Checklists are saved only in each browser. Classroom view does not collect student answers.

## Data and checks

The CSV is the existing Day 2 course dataset supplied by Mohan Bi. The lesson's numerical reference values refer to that file. Research context: https://doi.org/10.1038/s41467-024-52511-2.

The core analysis uses drought minus control consistently. For WSA, the expected difference is approximately -0.144390, with a Welch 95% confidence interval of -0.237623 to -0.051157 and p = 0.006998. The selected sample sizes are 20 control and 7 drought units. For soil pH, the difference is approximately +0.845786 with interval +0.602941 to +1.088630 and p = 0.000047476.
