# Render the tutorial and create complete student/source/publication packages.
# Run from this folder in RStudio: source("build.R")
args <- commandArgs(trailingOnly = TRUE)
project_dir <- if (length(args)) normalizePath(args[1]) else getwd()
setwd(project_dir)
if (!rmarkdown::pandoc_available()) {
  bundled <- "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/tools/aarch64"
  if (file.exists(file.path(bundled, "pandoc"))) Sys.setenv(RSTUDIO_PANDOC = bundled)
}
dir.create("dist", showWarnings = FALSE)
knitr::purl("D2_test_v2.Rmd", output = "Day2_complete.R", documentation = 0,
            quiet = TRUE)
qa_dir <- tempfile("day2-render-")
dir.create(qa_dir)
file.copy(c("MultiFactor_data.csv", "Day2_bootstrap_demo.R"), qa_dir)
rmarkdown::render("D2_test_v2.Rmd", output_file = "index.html",
                  output_dir = "dist", knit_root_dir = qa_dir,
                  envir = new.env(parent = globalenv()), quiet = TRUE,
                  encoding = "UTF-8")
downloads <- c("MultiFactor_data.csv", "Day2_starter.R", "Day2_complete.R",
               "Day2_bootstrap_demo.R", "D2_test_v2.Rmd")
file.copy(downloads, "dist", overwrite = TRUE)
student_files <- c("ABV_Day2.Rproj", "Day2_starter.R", "MultiFactor_data.csv")
student_zip <- file.path(project_dir, "dist", "Day2_student_files.zip")
if (file.exists(student_zip)) unlink(student_zip)
utils::zip(student_zip, files = student_files, flags = "-q")
source_files <- c(student_files, "D2_test_v2.Rmd", "Day2_complete.R",
                  "Day2_bootstrap_demo.R", "build.R", "README.md",
                  "assets/tutorial.css", "assets/navigation.html", "assets/interaction.html")
source_zip <- file.path(project_dir, "dist", "Day2_tutorial_source.zip")
if (file.exists(source_zip)) unlink(source_zip)
utils::zip(source_zip, files = source_files, flags = "-q")
unlink(qa_dir, recursive = TRUE)
publish_stage <- tempfile("day2-publish-")
dir.create(publish_stage)
publish_folder <- file.path(publish_stage, "day2_v2")
dir.create(publish_folder)
file.copy(list.files("dist", full.names = TRUE), publish_folder)
github_zip <- file.path(project_dir, "Day2_GitHub_ready.zip")
if (file.exists(github_zip)) unlink(github_zip)
setwd(publish_stage)
utils::zip(github_zip, files = list.files("day2_v2", recursive = TRUE, full.names = TRUE), flags = "-q")
setwd(project_dir)
unlink(publish_stage, recursive = TRUE)
cat("Built dist/index.html, student/source downloads, and Day2_GitHub_ready.zip.\n")
