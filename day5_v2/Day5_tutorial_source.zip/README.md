# Day 5: Read a tree, rank the factors

A practical for a two-hour class slot, with a 105-minute core including a five-minute break, for biology bachelor students who have completed the earlier R tutorials. Students predict `Decom` from the twelve 0/1 global change factor columns. An illustrative CART tree comes first, followed by five-fold cross-validation on all eligible observations, pruning and comparison of the two tree structures. Guided random forest follows, with descending permutation importance.

## Open the tutorial

Open [dist/index.html](dist/index.html) in a browser. Download and extract `Day5_student_files.zip`, open `ABV_Day5.Rproj` in RStudio, and save a personal copy of `Day5_starter.R`. The ZIP includes the project, starter, unchanged CSV and data dictionary. Students install `rpart`, `rpart.plot` and `randomForest` before class. All analysis runs locally in RStudio; the webpage is static. Progress stays in the browser.

The complete reference script is a separate download so students can attempt the tasks first. The tutorial contains expandable checks, a reference tree, a ranking figure, code-copy buttons, step tracking and print support.

## Two-hour structure

| Step | Minutes |
|:---|---:|
| 0. Question and setup | 10 |
| 1. Factor matrix, selection and split | 15 |
| 2. Build and plot CART | 15 |
| 3. Repeat CART with cross-validation and prune | 25 |
| Break | 5 |
| 4. Guided random forest | 20 |
| 5. Sort and interpret importance | 15 |
| **Total** | **105** |

## Data and model choices

`MultiFactor_data.csv` is copied unchanged from Day 4. The original 353-row file contains 93 single-factor records twice, under named codes and `remark = "1"`. Selecting `CT/1/2/5/8` retains one copy of each unit (260 records); complete cases for `Decom` and the twelve indicators leave 252. No mean imputation is used. IDs, treatment labels, factor counts, the response-derived dissimilarity index and other soil responses are excluded from predictors.

`Decom` is proportional tea litter dry mass loss during the 42-day incubation. Although the study calls it a decomposition rate, this teaching variable is an accumulated proportion, not a fitted per-day decay constant.

A fixed seed 505 assigns 189 units to training and 63 to testing **only to illustrate the first CART tree in Steps 1–2**. Step 1 discusses why fitting and evaluating on the same observations can give an optimistic result. Step 2 CART uses `method = "anova"`, `maxdepth = 3`, `minbucket = 10`, `cp = 0.01`, and `xval = 0`.

From Step 3, both model workflows use all **252** eligible observations. Seed 505 creates a balanced five-fold allocation, supplied as `xval = cv_folds` to CART. Step 3 chooses the `CP` with minimum `xerror` and plots `tree_cv_pruned`, fitted using all 252 observations. The minimum CART CV error was also used to choose tree size, so it is an internal classroom check, not an independent final test.

The full-data random forest has `ntree = 25`, `mtry = 4`, `nodesize = 5`, `importance = TRUE`, and `nPerm = 50`. Here, 50 means repeated predictor permutations on OOB data for importance within each tree. It does not mean response permutations, 50 forest refits or importance p-values. `importance(type = 1, scale = FALSE)` supplies unscaled increases in OOB MSE. These values are sorted descending and labelled in squared proportion units, rather than as percentages. OOB error from the full-data forest is an internal check.

The folds are allocated at the experimental-unit level and may share treatment combinations. Neither the illustrative split nor this CV design specifically validates unseen combinations, new sites or new experiments.

See [Instructor_notes.md](Instructor_notes.md) for the reference results, pacing and interpretation guidance.

## Rebuild and publish

Edit `D5_tree_models_v2.Rmd` and `assets/`. From this folder, run `source("build.R")` in RStudio or `Rscript --vanilla build.R`. Building requires `rmarkdown`, `knitr`, the three analysis packages and Pandoc. RStudio normally supplies Pandoc; the build also detects the existing macOS RStudio path used in the other course tutorials.

The build executes all analysis code against a temporary CSV copy, generates `Day5_complete.R` with `knitr::purl`, and writes:

- `dist/index.html` and adjacent student/source downloads.
- `day5_v2/`, containing the same publication files.
- `Day5_GitHub_ready.zip`, containing the `day5_v2` folder.

Upload the entire `day5_v2` folder beside the earlier day folders in the course's GitHub Pages publishing location. Extract the publication ZIP first if using it. The intended URL after publication is `https://mohanb96.github.io/Ecological-data-analysis-with-R/day5_v2/`. Creating these local files does not publish the page.

Research context: Bi et al. (2024), [Number and dissimilarity of global change factors influences soil properties and functions](https://doi.org/10.1038/s41467-024-52511-2). Official method references appear in the tutorial.
