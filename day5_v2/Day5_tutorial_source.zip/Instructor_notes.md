# Instructor notes: Day 5

## Aim and preparation

Teach two complementary ways of examining the same prediction problem: a single interpretable regression tree and a small forest with ranked predictive importance. The response is `Decom`; the only predictors are P, C, L, N, A, I, SU, FU, H, M, S and D, all numeric 0/1 indicators. Both methods are regression models. There is no response conversion into classes.

Ask students to install `rpart`, `rpart.plot` and `randomForest` before class. Open the page and student project yourself and confirm package availability before the clock starts. The two-hour route assumes R/RStudio are already installed, as on the earlier course days. Allow extra support outside the route for installation problems. Prior knowledge: selecting columns, logical row selection, `NA`, simple model formulas and interpreting a response proportion. Students need not write functions or loops.

## Facilitation within 120 minutes

| Minutes | Activity and instructor checkpoint |
|:---|:---|
| 0–10 | Explain the continuous response and binary predictors. Students make one ecological prediction and load packages. |
| 10–25 | Run the supplied selection/check/split code together. Verify 252 complete units and the illustrative 189/63 split. Discuss why accurate training predictions do not establish good prediction on new observations. Ask students to explain one selected row and why the dot formula is safe only after column selection. |
| 25–40 | Fit and plot the first CART using the illustrative training subset. Explain a leaf mean and numeric 0.5 split. Ask for the first split and lowest leaf before opening the reference figure. |
| 40–65 | Explain five-fold CV and OOB error (5 minutes), return to all 252 observations and create the folds (5), select CP and prune/plot CART (5), then compare the original and pruned paths and discuss CV uncertainty and size-selection optimism (10). |
| 65–70 | Save and take a five-minute break. |
| 70–90 | Introduce forest averaging and OOB observations briefly, then students fill `ntree` and `nPerm`, fit the forest on all 252 observations and explain `mtry`. Avoid the package's variance-explained summary as a second required performance metric. |
| 90–105 | Run extraction together, let students write the descending sort, then plot and interpret all twelve factors. Ask whether a large importance value means a positive ecological effect. |

All six steps are core and take 105 minutes, including the break, within the two-hour class slot. If the group falls behind, demonstrate the supplied CV commands and keep the tree and importance interpretation work. Do not add package installation, parameter searches or further forest runs to the scheduled activities. Students who finish early can describe a combination-level holdout design verbally; it is not another required computation.

## Data integrity and validation scope

The supplied CSV has 353 rows. The 93 rows with named single-factor labels match the 93 `remark = "1"` records in all columns except `X` and `remark`, in the same order after resetting row names. Selecting summary labels `CT`, `1`, `2`, `5`, `8` leaves 260 candidate units, not 353 independent units. Do not call `unique()` on the factor matrix: distinct microcosms can legitimately share the same combination.

There are no missing factor indicators in this selection. Eight `Decom` values are missing: X IDs **187, 216, 229, 251, 297, 344, 349, 356**. Complete-case filtering leaves **252** units at Lv 0/1/2/5/8 with counts **20/91/45/49/47**. Indicator row sums equal Lv. The original file is preserved; unrelated missing soil measurements do not affect this selection.

The fixed unit-level 75/25 split uses seed 505 and is used only for the first CART illustration in Steps 1–2. From Step 3 onward, use all **252** eligible observations. Seed 505 creates `cv_folds <- sample(rep(1:5, length.out = nrow(model_data)))`, with fold sizes **51, 51, 50, 50, 50**. CART receives this allocation as `xval = cv_folds`. Each held-out observation is predicted by a CART model fitted to the other four folds. The final pruned CART and importance forest are fitted using all 252 observations.

The illustrative split and CV folds may share treatment combinations; claims about unseen combinations need a combination-level split, and claims about new sites or experiments need external validation. Step 3 selects a tree size by minimum CV error. That same CV error is therefore optimistic after selection and is not an unbiased final performance estimate. The original `tree_model` remains available for discussing the first illustration.

Keep `dissim` out of prediction. The study derived the supplied dissimilarity index using single-factor soil response information, including decomposition. The requested factor-only model avoids this additional response-derived information.

## Reference results

These values were checked with R 4.3.1, rpart 4.1.24, rpart.plot 3.1.2 and randomForest 4.7-1.1. Small software-dependent differences are possible. Students should interpret their output.

The first, illustrative CART uses the 189-unit training subset, whose mean is **0.6455760**. It first splits on salinity and has five leaves:

| Complete path | n | Leaf prediction |
|:---|---:|---:|
| S = 1, D = 1 | 24 | 0.5581046 |
| S = 1, D = 0 | 26 | 0.6403585 |
| S = 0, D = 0 | 108 | 0.6573470 |
| S = 0, D = 1, L = 0 | 20 | 0.6674770 |
| S = 0, D = 1, L = 1 | 11 | 0.6933655 |

At S = 1, the drought-present minus drought-absent contrast is **−8.2254 percentage points**. At S = 0, the observed drought-present group mean is **0.6766632**, compared with **0.6573470** without drought, a contrast of **+1.9316 percentage points**. The latter pools the two lithium leaves by their counts. Neither contrast holds the other ten factors fixed. It is unsuitable to call these estimates of isolated causal drought effects.

The full-data forest ranking is **S, D, L, FU, C, SU, N, H, M, A, I, P**, from highest to lowest unscaled OOB permutation importance. The first three raw increases in MSE are approximately **0.001293521**, **0.0004253746**, **0.00004980540**. Values for H, M, A, I and P are slightly negative in this run. No significance or directional meaning follows from those signs.

Step 3 repeats CART on all 252 observations with the same depth, leaf-size and initial CP settings, but `xval = cv_folds`. The overall response mean is **0.6471768**. The minimum relative CV error is approximately **0.5193979** at **CP = 0.01755756**, selecting **two splits / three leaves**. The full-data five-leaf candidate has training relative error **0.4829679** and CV error **0.5241643**; students should notice that lower training error need not mean lower validation error. The pruned paths predict **0.5599603** for S = 1, D = 1 (n = 30); **0.6408195** for S = 1, D = 0 (n = 40); and **0.6629503** for S = 0 (n = 182). Pruning removes the copper (`C`) split within S = 1, D = 1 and the drought split within S = 0. Lithium was present in the first illustrative tree but is already absent from the full-data candidate before pruning. Interpret these changes as results of the fitting and size-selection procedure, not evidence of absent ecological effects. Small CV differences and software-dependent fold allocation can change the chosen size.

The objects `tree_cv` and `tree_cv_pruned` do not overwrite `tree_model`. `xpred.rpart(tree_cv, xval = cv_folds)[, best_row]` supplies the held-out CART predictions at the selected candidate size. The `xerror` column is relative CV error, not MSE or RMSE; for this unweighted regression example, RMSE is `sqrt(xerror * tree_cv$frame$dev[1] / nrow(model_data))`. The full-data forest calculates the 50 importance permutations.

CV and OOB error are distinct internal estimates. OOB regression predictions average only trees whose bootstrap samples omitted an observation, whereas five-fold CV rotates held-out folds. The forest's `predicted` component contains OOB predictions; `predict(rf_model, newdata = model_data[, factor_names])` would instead give in-sample predictions. Step 1 distinguishes fitting using every observation from evaluating on those same fitting predictions: a full-data final fit can be appropriate, but its in-sample fit is not independent validation.

The full-data forest's OOB MSE is approximately **0.001417730**, giving OOB RMSE **0.03765275** or **3.765275 percentage points**. OOB and five-fold CV need not match because their resampling and prediction procedures differ.

## Interpretation points to listen for

- A 0/1 predictor does not make this classification. The response determines the task.
- A 0.5 split separates two applied-treatment states, rather than locating a dose threshold.
- A leaf prediction is the mean of the training observations reaching that leaf, not an individual guarantee.
- A lower node is conditional on every earlier split; lithium in the first illustrative tree belongs within S = 0 and D = 1.
- A factor appearing below another does not prove a biological interaction. An additive response can also produce sequential splits. Conditional patterns generate hypotheses; formal interaction testing needs an explicit comparison, and synergy/antagonism needs a defined null expectation.
- “Importance” describes predictive contribution, not a coefficient, direction, causal effect or p-value. With co-occurring factors, importance can be shared or distorted by shuffling into poorly represented combinations.
- Small forests and finite CV folds give uncertain rankings and scores. Fifty importance shuffles do not make 25 trees a research-grade default.

The user-requested permutation count is implemented as `randomForest(..., nPerm = 50)`: OOB predictor permutations per tree for regression importance. It is not `rfPermute(nrep = 50)`, which is a different response-permutation procedure involving repeated model fits. No response-permutation significance test is taught or run. Use `importance(type = 1, scale = FALSE)` and label the output as an increase in MSE, even though the package's raw column name contains `%IncMSE`.

## End-of-practical evidence

Look for a reproducible script; an explanation that the fixed training/test split is only the first CART illustration; a CV-selected CP and pruned-tree path interpretation with units; a distinction between five-fold CV and OOB error; all twelve factors sorted descending; and an explanation that importance lacks effect direction. Browser checkboxes are self-checks, not submitted assessment.

The build runs the full analysis in a temporary folder and embeds reference figures in a self-contained HTML page. The student ZIP does not contain a completed solution. Instructor source and separate complete-script downloads support rebuilding and troubleshooting. See README.md for publication instructions and the tutorial's references for the study and official package documentation.
