# Run from this directory: source("build.R") or Rscript --vanilla build.R.
args <- commandArgs(trailingOnly = TRUE)
project_dir <- if (length(args)) normalizePath(args[1]) else getwd()
setwd(project_dir)
needed <- c("rmarkdown", "knitr", "rpart", "rpart.plot", "randomForest")
missing <- needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Install these packages before building: ", paste(missing, collapse = ", "))
if (!rmarkdown::pandoc_available()) {
  bundled <- "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/tools/aarch64"
  if (file.exists(file.path(bundled, "pandoc"))) Sys.setenv(RSTUDIO_PANDOC = bundled)
}
if (!rmarkdown::pandoc_available()) stop("Pandoc is required. Build from RStudio or install Pandoc.")
dir.create("dist", showWarnings = FALSE)
knitr::purl("D5_tree_models_v2.Rmd", output = "Day5_complete.R", documentation = 0, quiet = TRUE)
qa_dir <- tempfile("day5-render-")
dir.create(qa_dir)
file.copy("MultiFactor_data.csv", qa_dir)
rmarkdown::render("D5_tree_models_v2.Rmd", output_file = "index.html", output_dir = "dist",
                  knit_root_dir = qa_dir, envir = new.env(parent = globalenv()),
                  quiet = TRUE, encoding = "UTF-8")
downloads <- c("MultiFactor_data.csv", "Day5_data_dictionary.csv", "Day5_starter.R",
               "Day5_complete.R", "D5_tree_models_v2.Rmd")
file.copy(downloads, "dist", overwrite = TRUE)
student_files <- c("ABV_Day5.Rproj", "Day5_starter.R", "MultiFactor_data.csv", "Day5_data_dictionary.csv")
source_files <- c(student_files, "D5_tree_models_v2.Rmd", "Day5_complete.R", "build.R",
                  "README.md", "Instructor_notes.md", "assets/tutorial.css",
                  "assets/navigation.html", "assets/interaction.html")
for (kind in c("student_files", "tutorial_source")) {
  target <- file.path(project_dir, "dist", paste0("Day5_", kind, ".zip"))
  if (file.exists(target)) unlink(target)
  utils::zip(target, files = if (kind == "student_files") student_files else source_files, flags = "-q")
}
unlink(qa_dir, recursive = TRUE)
dir.create("day5_v2", showWarnings = FALSE)
file.copy(list.files("dist", full.names = TRUE), "day5_v2", overwrite = TRUE)
github_zip <- file.path(project_dir, "Day5_GitHub_ready.zip")
if (file.exists(github_zip)) unlink(github_zip)
utils::zip(github_zip, files = list.files("day5_v2", recursive = TRUE, full.names = TRUE), flags = "-q")
cat("Built dist/index.html, student/source downloads, day5_v2/ and Day5_GitHub_ready.zip.\n")
