# Day 1 tutorial

This new tutorial preserves the original setup, R basics, inspection, subsetting, cleaning, and export sequence, with a control–drought question, student tasks, reference checks, and a first figure. The original Day 1 files are unchanged.

## Student use

Open `dist/index.html` or the hosted website. Students download `Day1_student_files.zip`, extract it, and open `ABV_Day1.Rproj`. The package contains only the project, dataset, and starter script. R code runs in RStudio; the web page provides instructions.

## Editing and rebuilding

Edit `D1_R_Intro_v2.Rmd` for teaching content, `assets/tutorial.css` for styling, and the other files in `assets/` for navigation and browser interactions. Rebuild in RStudio with:

```r
source("build.R")
```

Or, from this directory in a terminal:

```sh
Rscript --vanilla build.R
```

The build requires R, the R packages `rmarkdown`, `knitr`, and `ggplot2`, and Pandoc. RStudio includes Pandoc. The script includes a fallback for this computer's RStudio installation. Rendering executes the lesson code against a temporary copy of the data; the original CSV is preserved.

`dist/index.html` includes its styling, browser scripts, and reference figure. Its adjacent files are the student downloads. Upload the complete contents of `dist/` to a static website. You can rename `index.html` to `D1_R_Intro_v2.html` when adding it to an existing GitHub Pages site, keeping the adjacent download files alongside it.

## Verification

The tutorial and complete reference script were run with R 4.3.1. Checks confirmed 353 source rows, 23 columns, 20 control observations, 7 drought-only observations, 27 selected WSA rows, missing-value counts, reported group means, and CSV/PNG output creation. Browser checks covered navigation, answer disclosure, code copying, progress persistence, and a phone viewport without horizontal page overflow.

## Data context

The CSV is the existing Day 1 course dataset supplied by Mohan Bi. Counts and example results are specific to that file. Research context: https://doi.org/10.1038/s41467-024-52511-2.
