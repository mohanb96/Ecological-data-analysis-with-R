# Render the standalone tutorial and prepare its student downloads.
# Requires rmarkdown, knitr, ggplot2, and Pandoc (included with RStudio).
args <- commandArgs(trailingOnly = TRUE)
project_dir <- if (length(args)) normalizePath(args[1]) else getwd()
setwd(project_dir)
if (!rmarkdown::pandoc_available()) {
  bundled <- "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/tools/aarch64"
  if (file.exists(file.path(bundled, "pandoc"))) Sys.setenv(RSTUDIO_PANDOC = bundled)
}
dir.create("dist", showWarnings = FALSE)
qa_dir <- tempfile("day1-render-")
dir.create(qa_dir)
file.copy("MultiFactor_data.csv", qa_dir)
rmarkdown::render("D1_R_Intro_v2.Rmd", output_file = "index.html",
                  output_dir = "dist", knit_root_dir = qa_dir,
                  envir = new.env(parent = globalenv()), quiet = TRUE,
                  encoding = "UTF-8")
downloads <- c("MultiFactor_data.csv", "Day1_starter.R", "Day1_complete.R", "D1_R_Intro_v2.Rmd")
file.copy(downloads, "dist", overwrite = TRUE)
zip_files <- c("ABV_Day1.Rproj", "Day1_starter.R", "MultiFactor_data.csv")
zip_path <- file.path(project_dir, "dist", "Day1_student_files.zip")
if (file.exists(zip_path)) unlink(zip_path)
utils::zip(zip_path, files = zip_files, flags = "-q")
source_files <- c(zip_files, "D1_R_Intro_v2.Rmd", "Day1_complete.R", "build.R", "README.md",
                  "assets/tutorial.css", "assets/navigation.html", "assets/interaction.html")
source_zip <- file.path(project_dir, "dist", "Day1_tutorial_source.zip")
if (file.exists(source_zip)) unlink(source_zip)
utils::zip(source_zip, files = source_files, flags = "-q")
unlink(qa_dir, recursive = TRUE)
cat("Built dist/index.html and student downloads.\n")
