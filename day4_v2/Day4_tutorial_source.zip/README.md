# Day 4: compare groups and describe a numerical trend

The two original Day 4 topics are combined into one beginner tutorial with a 130-minute core route, including a break. Allow extra time for setup and questions within a three-hour practical. The core runs from Step 0 to Step 5: five whole-class R questions, a four-group WSA ANOVA with Tukey comparisons, a guided Decom regression against the number of factors and an independent Decom regression against factor dissimilarity. Treatment inspection flows directly into ANOVA and comparisons. Step 4's Check contains the slope and R² interpretation.

Two thinking questions follow the last core step for students who finish early: how to combine Lv and dissim in one regression, and how the dissimilarity index was calculated using seven soil functions as traits, connecting to Day 3's trait-based comparison of fungal isolates. The combined-model code and Check are supplied. There is no separate save/report assignment or general optional-model section.

## Read and publish

Open `dist/index.html` locally. The static page needs no R server or online account; students execute R in RStudio. Checklists are stored only in their browser.

Upload the entire `day4_v2` folder beside `day1_v2`, `day2_v2` and `day3_v2` in the existing GitHub Pages publishing root. Alternatively, unzip `Day4_GitHub_ready.zip` and upload the contained folder. Upload its files and folder, not an unextracted ZIP alone.

Expected URL after publication:

https://mohanb96.github.io/Ecological-data-analysis-with-R/day4_v2/

Course-homepage Markdown:

```markdown
[Day 4: ANOVA and linear regression](https://mohanb96.github.io/Ecological-data-analysis-with-R/day4_v2/)
```

## Student files and editing

`Day4_student_files.zip` contains the project, starter, original CSV and dictionary. The required analysis uses base R plus `ggplot2`. Students extract the ZIP, open `ABV_Day4.Rproj` and follow the website. The complete core reference script is a separate download.

Edit `D4_models_v2.Rmd` and `assets/`, then run `source("build.R")` from this folder or `Rscript --vanilla build.R`. Building requires `rmarkdown`, `knitr`, `ggplot2` and Pandoc. Rendering executes the core and the early-finisher combined-model example against a temporary data copy. The complete core script is generated with `knitr::purl`; refresher questions, reference-only figures and the early-finisher example are excluded. Both simple regressions and their plot recipes are included so the script runs from a fresh session. Students add brief interpretation notes in the analysis steps; no result-table or figure exports are required.

## Data and scope

`MultiFactor_data.csv` is byte-for-byte identical to the supplied Day 4 CSV. No original course files were changed. Four explicit remark codes select the group example: CT control, D drought, H herbicide, S salinity. The regression includes Lv 0, 1, 2, 5 and 8. The file contains 93 single-factor records twice: under named treatments and under the numeric summary label "1"; all measurements match after excluding the X and remark columns. The regression selects remark labels CT/1/2/5/8 to retain one copy of those records. There are 260 candidate units and 252 complete Decom/Lv records: 20, 91, 45, 49 and 47 at the five levels. The eight excluded record X IDs are 187, 216, 229, 251, 297, 344, 349 and 356. The original CSV is preserved.

The four-group selection is for teaching a manageable comparison family, not an unbiased survey of all factors or a preregistered discovery. The ANOVA/Tukey results are conditional on independent errors and a suitable common-variance model. The regression shows visibly unequal spread and some departure from a simple mean trend; its ordinary intervals are labelled model-based and its slope is interpreted descriptively.

The independent dissimilarity exercise uses the provided index and explains its within-Lv normalisation and origin in single-factor responses. In the supplied file, controls and single-factor records have dissim=0; the index varies within the multi-factor levels. Adding it does not isolate a causal dissimilarity effect or validate prediction on new data. Research context: Bi et al. (2024), https://doi.org/10.1038/s41467-024-52511-2.

## Reference checks

WSA group n: 20, 7, 8, 10 (total 45). Overall ANOVA F(3,41)=8.246, p=0.000207. Drought-Control=-0.144390, Tukey interval [-0.253791,-0.034989], adjusted p=0.005471. Herbicide-Control=+0.003903; Salinity-Control=-0.138783. Tukey adjustment covers all six pairs.

Regression n=252 at Lv 0/1/2/5/8 (20/91/45/49/47). Fitted intercept=0.667661656; slope=-0.006436643 proportion per factor (-0.643664 percentage points); ordinary 95% CI [-0.008393233,-0.004480052]; R-squared=0.1437735. The intercept now estimates the mean at the observed control level under the fitted line; the observed control mean is 0.662329. The slope and R² interpretation is supplied inside Step 4's Check. The independent dissimilarity regression also retains all 252 units: intercept=0.6659648, slope=-0.0637695 per whole index unit, ordinary 95% CI [-0.07992449,-0.04761452], R²=0.1946913. A 0.1 index increase corresponds to -0.637695 percentage points of mass loss. The two regression samples have matching record IDs. The additive model with both Lv and dissim appears in the first early-finisher thinking question. See Instructor_notes.md for guidance.
