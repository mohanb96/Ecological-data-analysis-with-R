# Day 4: compare groups and describe a numerical trend

The two original Day 4 topics are combined into one three-hour beginner tutorial. It follows Days 1-3: six whole-class R questions, ecological questions, explicit tasks, collapsible checks, saved outputs, and optional extensions. The core uses one four-group WSA ANOVA with Tukey comparisons, followed by one Decom regression against factor count. Multiple regression, robustness checks and a categorical alternative to the straight line are optional.

## Read and publish

Open `dist/index.html` locally. The static page needs no R server or online account; students execute R in RStudio. Checklists are stored only in their browser.

Upload the entire `day4_v2` folder beside `day1_v2`, `day2_v2` and `day3_v2` in the existing GitHub Pages publishing root. Alternatively, unzip `Day4_GitHub_ready.zip` and upload the contained folder. Upload its files and folder, not an unextracted ZIP alone.

Expected URL after publication:

https://mohanb96.github.io/Ecological-data-analysis-with-R/day4_v2/

Course-homepage Markdown:

```markdown
[Day 4: ANOVA and linear regression](https://mohanb96.github.io/Ecological-data-analysis-with-R/day4_v2/)
```

## Student files and editing

`Day4_student_files.zip` contains the project, starter, original CSV and dictionary. The required analysis uses base R plus `ggplot2`. Students extract the ZIP, open `ABV_Day4.Rproj` and follow the website. The reference script and optional HC3 helper are separate downloads.

Edit `D4_models_v2.Rmd` and `assets/`, then run `source("build.R")` from this folder or `Rscript --vanilla build.R`. Building requires `rmarkdown`, `knitr`, `ggplot2` and Pandoc. Rendering executes both core and optional examples against a temporary data copy. The complete core script is generated with `knitr::purl`; refresher questions, answer-only plots, student exercise solution and optional sections are excluded. Student predictions are supplied as a ready-to-run recipe because interpreting them is the exercise.

## Data and scope

`MultiFactor_data.csv` is byte-for-byte identical to the supplied Day 4 CSV. No original course files were changed. Four explicit remark codes select the group example: CT control, D drought, H herbicide, S salinity. The regression is deliberately restricted to mixtures with Lv 2, 5 or 8, then complete cases for Decom/Lv: 147 candidate units, 141 retained, six missing Decom records. It does not pool the named single-factor records and additional numeric-label records at Lv=1.

The four-group selection is for teaching a manageable comparison family, not an unbiased survey of all factors or a preregistered discovery. The ANOVA/Tukey results are conditional on independent errors and a suitable common-variance model. The regression shows visibly unequal spread and some departure from a simple mean trend; its ordinary intervals are labelled model-based and its slope is interpreted descriptively. Optional HC3 intervals do not repair dependence, mean-model misspecification or factor-identity confounding.

The dissimilarity extension uses the provided index and explains its within-Lv normalisation and origin in single-factor responses. Adding it does not isolate a causal dissimilarity effect or validate prediction on new data. Research context: Bi et al. (2024), https://doi.org/10.1038/s41467-024-52511-2.

## Reference checks

WSA group n: 20, 7, 8, 10 (total 45). Overall ANOVA F(3,41)=8.246, p=0.000207. Drought-Control=-0.144390, Tukey interval [-0.253791,-0.034989], adjusted p=0.005471. Herbicide-Control=+0.003903; Salinity-Control=-0.138783. Tukey adjustment covers all six pairs.

Regression n=141 at Lv 2/5/8 (45/49/47). Fitted slope=-0.00744916 proportion per factor (-0.744916 percentage points); ordinary 95% CI [-0.01113686,-0.00376147]; R-squared=0.102944. These references differ from the original all-row regression because the analysis population is explicitly different. See Instructor_notes.md for interpretive guidance.
