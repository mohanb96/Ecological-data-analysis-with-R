# Run from this directory: source("build.R") or Rscript --vanilla build.R.
args <- commandArgs(trailingOnly = TRUE)
project_dir <- if (length(args)) normalizePath(args[1]) else getwd()
setwd(project_dir)
if (!rmarkdown::pandoc_available()) {
  bundled <- "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/tools/aarch64"
  if (file.exists(file.path(bundled, "pandoc"))) Sys.setenv(RSTUDIO_PANDOC = bundled)
}
dir.create("dist", showWarnings = FALSE)
knitr::purl("D4_models_v2.Rmd", output = "Day4_complete.R", documentation = 0,
            quiet = TRUE)
qa_dir <- tempfile("day4-render-")
dir.create(qa_dir)
file.copy(c("MultiFactor_data.csv", "Day4_robust_demo.R"), qa_dir)
rmarkdown::render("D4_models_v2.Rmd", output_file = "index.html",
                  output_dir = "dist", knit_root_dir = qa_dir,
                  envir = new.env(parent = globalenv()), quiet = TRUE,
                  encoding = "UTF-8")
downloads <- c("MultiFactor_data.csv", "Day4_data_dictionary.csv", "Day4_starter.R",
               "Day4_complete.R", "Day4_robust_demo.R", "D4_models_v2.Rmd")
file.copy(downloads, "dist", overwrite = TRUE)
student_files <- c("ABV_Day4.Rproj", "Day4_starter.R", "MultiFactor_data.csv",
                   "Day4_data_dictionary.csv")
student_zip <- file.path(project_dir, "dist", "Day4_student_files.zip")
if (file.exists(student_zip)) unlink(student_zip)
utils::zip(student_zip, files = student_files, flags = "-q")
source_files <- c(student_files, "D4_models_v2.Rmd", "Day4_complete.R",
                  "Day4_robust_demo.R", "build.R", "README.md", "Instructor_notes.md",
                  "assets/tutorial.css", "assets/navigation.html", "assets/interaction.html")
source_zip <- file.path(project_dir, "dist", "Day4_tutorial_source.zip")
if (file.exists(source_zip)) unlink(source_zip)
utils::zip(source_zip, files = source_files, flags = "-q")
unlink(qa_dir, recursive = TRUE)
dir.create("day4_v2", showWarnings = FALSE)
file.copy(list.files("dist", full.names = TRUE), "day4_v2", overwrite = TRUE)
github_zip <- file.path(project_dir, "Day4_GitHub_ready.zip")
if (file.exists(github_zip)) unlink(github_zip)
utils::zip(github_zip, files = list.files("day4_v2", recursive = TRUE, full.names = TRUE), flags = "-q")
cat("Built dist/index.html, downloads, day4_v2/ and Day4_GitHub_ready.zip.\n")
