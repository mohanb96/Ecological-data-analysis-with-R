# Instructor notes: Day 4

## Main decisions

Keep the lecture's ANOVA-to-linear-model progression. The main practical asks two clearly separated questions using the familiar soil CSV. Four treatment groups keep Tukey's all-pair comparison family to six comparisons. The required regression uses mixtures with two, five or eight factors only. Multiple regression and model comparison are extensions, not additional tasks required to finish in three hours.

Timing: refresher 15, questions 10, inspect groups 20, group model/diagnostics 25, ANOVA/Tukey 25, break 10, fit regression 30, interpret/diagnose 20, prediction exercise 15, save/report 10 = 180 minutes.

## Teaching corrections

- Select explicit treatment names. `Lv == 1` alone also includes records labelled "1"; `unique(...)[1:13]` depends on row order.
- H means herbicide, not heat. WSA and Decom are proportions; a difference times 100 gives percentage points. Decom is proportional tea litter mass loss during incubation, not a measured daily rate.
- Explain experimental-unit independence through design; a residual plot cannot establish it.
- Fit the model to obtain residuals, inspect diagnostics, then interpret tests. Do not turn Shapiro or Levene p-values into an automatic pass/fail switch. Do not delete legitimate observations merely to satisfy a test.
- ANOVA asks whether all four population means are equal. A small global p-value does not establish that every treatment differs from control.
- Tukey adjustment covers all six pairs even when the report highlights three control contrasts. Do not substitute its intervals after running Welch ANOVA: the procedures have different variance assumptions. Unequal n is accounted for approximately in the Tukey implementation; it does not remove the common-variance requirement.
- A nonsignificant contrast is not proof of equality. A large p-value does not establish ecological equivalence. Discuss magnitude, uncertainty and biological context.
- ANOVA with a categorical predictor and regression with a numerical predictor are both linear models. Do not call today's analysis a generalized linear model or introduce `glm()` without a separate distribution/link discussion.

## ANOVA reference

45 observed WSA values, no WSA missingness in this selection: Control n20 mean0.606272 SD0.073452; Drought n7 mean0.461882 SD0.098819; Herbicide n8 mean0.610175 SD0.120254; Salinity n10 mean0.467489 SD0.101412. The unequal counts and spreads warrant discussion. Diagnostics are not certificates of validity. Classical F(3,41)=8.246, p0.000207. Optional Welch F=7.4408, denominator df15.075, p0.002766; both offer evidence against a common mean, under their respective assumptions.

Tukey Drought-Control difference -0.144390, 95% family-wise interval -0.253791 to -0.034989, p-adj0.005471. Salinity-Control -0.138783, interval -0.235266 to -0.042301, p-adj0.002205. Herbicide-Control +0.003903, interval -0.100310 to +0.108116, p-adj0.999633. The herbicide estimate is small but the interval still permits differences of practical interest. An acceptable report need not discuss all six rows; it must preserve the six-pair adjustment family.

## Regression reference and limitations

Candidate rows:147; retained:141; excluded record X IDs229,251,297,344,349,356. Observed factor counts2,5,8 have45,49,47 retained units respectively. At a given count, units receive different factor combinations. These are not repeated measurements of one common treatment mixture.

OLS intercept0.67405061, slope-0.00744916; ordinary slope interval[-0.01113686,-0.00376147], p0.0001049; R-squared0.102944. Slope corresponds to -0.745 percentage points of litter mass loss per additional factor under a common straight-line summary. Fitted values at2,5,8 are0.6591523,0.6368048,0.6144573; 8-minus-2 contrast-0.0446950, or-4.47 percentage points. Lv0 is outside the fitted subset, so the intercept is not an observed control mean.

Actual level means are0.651922,0.650085,0.607534. Observed SDs increase0.030796,0.052759,0.067833. Discuss unequal spread and imperfect straight-line representation openly. Model-based ordinary CIs and the shaded mean-response band assume a suitable error/mean model; do not present them as guaranteed calibration. Optional HC3 check addresses unequal variance only and uses approximate t inference; verify the helper against `car::hccm(model,type="hc3")` if desired. Optional categorical-Lv comparison tests a mean restriction under classical error assumptions; its p-value is itself conditional and not a universal model-selection rule.

Factor identities and combinations differ along the count gradient, so the fitted slope is not an isolated causal effect of factor number, a factor-specific effect, or an interaction coefficient. Avoid extrapolation beyond2-8 and distinguish interpolation at unobserved3/4/6/7 from actual observed counts. R-squared is in-sample fit, not forecast performance.

## Optional multiple regression

Use the same complete rows for `Decom ~ Lv` and `Decom ~ Lv + dissim` (141 here); otherwise nested comparison is invalid. Approximate reference coefficients: Lv-0.004166, dissim-0.080691; R-squared0.2246, adjusted0.2133; nested F21.644, p7.609e-06. The supplied dissimilarity index is derived from single-factor effect profiles and scaled within factor-count levels. A0.1 increase describes a relative within-level index change, not a universal raw distance. Adding it does not control all factor identities, prove mechanism, or assess held-out prediction. The plus sign fits additive terms, not a statistical interaction.

## Formative assessment

Give credit for choosing the right data subset, explaining factor versus numeric predictors, reading a contrast's direction and units, keeping the multiple-comparison family intact, interpreting a slope and R-squared, and stating a diagnostic or design limitation. Do not require a particular p-value threshold as the final ecological conclusion. Two short evidence-based paragraphs are more useful than a list of stars.
