# Instructor notes: Day 4

## Main decisions

Keep the lecture's ANOVA-to-linear-model progression. The main practical asks two clearly separated questions using the familiar soil CSV. Four treatment groups keep Tukey's all-pair comparison family to six comparisons. The guided regression includes zero, one, two, five and eight factors, retaining one copy of the single-factor records. Students then repeat simple linear regression with the same Decom response and the supplied dissimilarity index. The core ends at Step 5. Two thinking questions for early finishers follow: combining both regression predictors and deriving the factor dissimilarity index.

Timing: refresher 15, questions 10, inspect groups 20, ANOVA/Tukey 25, break 10, guided regression and its Check 30, independent dissimilarity regression 20 = 130 minutes. Allow up to 50 additional minutes for setup, questions and the early-finisher work within a three-hour practical. Treatment inspection is followed directly by ANOVA and comparisons, with no separate group-model checking section.

## Teaching corrections

- Select explicit treatment names. `Lv == 1` alone also includes records labelled "1"; `unique(...)[1:13]` depends on row order.
- H means herbicide, not heat. WSA and Decom are proportions; a difference times 100 gives percentage points. Decom is proportional tea litter mass loss during incubation, not a measured daily rate.
- Explain experimental-unit independence through design; a residual plot cannot establish it.
- Fit `group_model <- aov(WSA ~ treatment, data = group_data)` at the start of ANOVA and comparisons, then call `summary()` and `TukeyHSD()` on that object. There is no separate group-diagnostic assignment or group-diagnostic export. Step 4's Check supplies the slope and R² interpretation. The former standalone interpretation/diagnostic section and its plot export have been removed.
- ANOVA asks whether all four population means are equal. A small global p-value does not establish that every treatment differs from control.
- Tukey adjustment covers all six pairs even when students focus on three control contrasts. Unequal n is accounted for approximately in the Tukey implementation; it does not remove the common-variance requirement.
- A nonsignificant contrast is not proof of equality. A large p-value does not establish ecological equivalence. Discuss magnitude, uncertainty and biological context.
- ANOVA with a categorical predictor and regression with a numerical predictor are both linear models. Do not call today's analysis a generalized linear model or introduce `glm()` without a separate distribution/link discussion.

## ANOVA reference

45 observed WSA values, no WSA missingness in this selection: Control n20 mean0.606272 SD0.073452; Drought n7 mean0.461882 SD0.098819; Herbicide n8 mean0.610175 SD0.120254; Salinity n10 mean0.467489 SD0.101412. The unequal counts and spreads warrant discussion. Diagnostics are not certificates of validity. Classical F(3,41)=8.246, p0.000207.

Tukey Drought-Control difference -0.144390, 95% family-wise interval -0.253791 to -0.034989, p-adj0.005471. Salinity-Control -0.138783, interval -0.235266 to -0.042301, p-adj0.002205. Herbicide-Control +0.003903, interval -0.100310 to +0.108116, p-adj0.999633. The herbicide estimate is small but the interval still permits differences of practical interest. Students can focus on the three control contrasts while preserving the six-pair adjustment family.

## Regression reference and limitations

Use remark labels CT/1/2/5/8 together with Lv 0/1/2/5/8. The 93 named single-factor records and the 93 rows labelled "1" contain identical measurements apart from X and remark. Select the latter copy once for this regression; do not treat both copies as independent units. The original CSV remains unchanged.

Candidate rows: 260; retained: 252; excluded record X IDs 187, 216, 229, 251, 297, 344, 349, 356. Candidate counts at Lv 0/1/2/5/8 are 20/93/47/50/50; retained counts are 20/91/45/49/47. The tutorial uses the requested description that different treatment units at each factor level received random-drawn factor combinations; Lv=0 denotes controls with no factors.

OLS intercept 0.667661656; slope -0.006436643; ordinary slope interval [-0.008393233, -0.004480052], p=4.870297e-10; R-squared=0.1437735. The slope corresponds to -0.644 percentage points per additional factor under the common line. Step 4's Check reports the slope in percentage points and R²=14.4%, alongside the model-based CI and plot. There is no separate prediction assignment.

Lv=0 is now inside the observed range. The intercept estimates mean litter mass loss at zero factors under the line fitted to all units. It can differ from the observed control mean, 0.662329, because the linear model does not give every level its own unconstrained mean.

## Independent exercise: factor dissimilarity

Use the same response, Decom, and the same 252 records as the guided regression. Check complete Decom/dissim rows; all selected records have dissim values, so none are lost. Fit the simple model `Decom ~ dissim`; the combined model is reserved for early finishers. Students make a new scatterplot and fitted line, interpret the slope for a 0.1 index increase, report R² and compare the two simple fits.

Reference intercept=0.6659648; slope=-0.0637695; ordinary 95% slope CI [-0.07992449, -0.04761452]; p=1.978336e-13; R²=0.1946913. A 0.1 increase corresponds to -0.637695 percentage points, with an ordinary interval approximately [-0.799245, -0.476145] percentage points. The dissimilarity model describes 19.5% of the observed variation, compared with 14.4% for the number-of-factors model on the same units.

The supplied index is normalised within levels of the number of factors. Controls and single-factor units have index zero. Interpret the simple model as a pooled association. Its R² describes fit to these observations; it does not establish causation or future predictive performance.

The starter and generated reference script cover both simple regressions. Students add brief interpretation notes in Step 5. There is no separate save/report section, export assignment or exit-question list.

## Two thinking questions for early finishers

1. Reuse the combined-regression example `Decom ~ Lv + dissim`. Ask students to interpret the dissimilarity coefficient at a fixed number of factors and compare fit using the same observations. Code and a collapsible Check are supplied.
2. Connect the factor dissimilarity question to Day 3's trait-based comparison of fungal isolates: individual global change factors are now the objects, and responses across seven measured soil functions form each factor's trait profile. Ask how the index was calculated for the 2-, 5- and 8-factor treatments. Prompt students to recall trait scaling and distances, then reason from differences between factor profiles to a measure for a combination of factors.

### Combined-model reference

Both models use the same 252 complete rows. Coefficients for Decom ~ Lv + dissim: intercept 0.668412694, Lv -0.001878838, dissim -0.051782824. R-squared=0.2000625, adjusted=0.1936373; nested F=17.521, p=3.943158e-05. A 0.1 index increase corresponds to about -0.518 percentage points at the same number of factors under the additive model. Controls and single-factor records have dissim=0; index variation occurs in multi-factor levels.

The index comes from single-factor response profiles and is normalised within levels of the number of factors. Adding it does not isolate a mechanism or establish held-out prediction; the plus sign specifies additive terms, not an interaction.

## Formative assessment

Give credit for choosing the right data subset, explaining factor versus numeric predictors, reading a contrast's direction and units, keeping the multiple-comparison family intact, interpreting a slope and R-squared, comparing the two simple regressions on matched observations, and stating a model or design limitation. Do not require a particular p-value threshold as the final ecological conclusion. Use the brief notes in the analysis steps for feedback; no separate report is required.
